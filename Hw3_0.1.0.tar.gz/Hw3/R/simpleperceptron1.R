#Simple perceptron
#my first step towards neural netwoks
#' @param a dataframe which is solved
#' @param learning rate
newx <- function (mydataf,learning) {



  input3<-c(9,9,9,9)
  input4<-c(9,9,9,9)
  output4<-c(9,9,9,9)
  testdf<-data.frame(input3,input4,output4)


  weight<-c(-2,3,1)
  for(i in 1:nrow(mydataf)){


    io<-c(1)
    i1=mydataf[i,1]
    i3=mydataf[i,2]
    ytarget= mydataf[i,3]
    z<-c((weight[1]*io)+ (weight[2]*i1)+ (weight[3]*io))
    if (z <= 0 ){
      yclass=0
    }
    else
    {
      yclass=1
    }

    if(yclass == ytarget){
      testdf[i,1]<-mydataf[i,1]
      testdf[i,2]<-mydataf[i,2]
      testdf[i,3]=(yclass)
    }

    else{
      while(yclass != ytarget){
        error<-c(ytarget-yclass)
        deltaweight1<-c(learning*error* io)
        deltaweight2<-c(learning*error* i1)
        deltaweight3<-c(learning*error* i3)
        weight[1]<-c(weight[1]+ deltaweight1)
        weight[2]<-c(weight[2]+ deltaweight2)
        weight[3]<-c(weight[3]+ deltaweight3)
        z<-c((weight[1]*io)+ (weight[2]*i1)+ (weight[3]*io))
        if (z < 0 ){
          yclass=0
        }
        else
        {
          yclass=1
        }


      }
      testdf [i,1]<-mydataf[i,1]
      testdf[i,2]<-mydataf[i,2]
      testdf[i,3]=(yclass)

    }



  }
  print(testdf)
}




